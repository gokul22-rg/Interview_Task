                                    # Interview Task

                                # Question Number : 1

# def largestElement(n):
#     max = n[0]
#     for x in n:
#         if x > max:
#             max = x
#
#             return max
#
#
# n = [10, 20, 90, 50, 80]
# print("Largest Element is:", largestElement(n))




                                # Question Number : 2

# n = [10, 20, 90, 50, 80]
# def largestElement(n):
#     first_largest = max(n[0], n[1])
#     second_largest = min(n[0], n[1])
#
#
#     for i in range(2,len(n)):
#         if n[i] > first_largest:
#             second_largest = first_largest
#             first_largest =n[i]
#
#         elif n[i] > second_largest:
#             second_largest = n[i]
#
#     return first_largest,second_largest
#
# print("Largest 2 Elements in the list :",largestElement(n))
#
#


                                # Question Number : 3


# def largest(n, m):
#     for i in range(m):
#         a = max(n)
#         print("Largest number "+ str(i+1) + "-", a)
#         n.remove(a)
#
#
# largest([1,2,3,4, 34 , 56, 55], 4)


                                    # Question Number : 4

#
# import math
#
#
# def isprime(n):
#     if n % 2 == 0 or n % 3 == 0 or n % 5 == 0:
#         return False
#     for i in range(7, math.floor(math.sqrt(n)), 2):
#         if n % i == 0:
#             return False
#     return True

#
# # Test case 1: The below line returns math domain error.Exception Handling is not Implemented.
# print(isprime(-7))
# # Test case 2: The below line returns False
#
# print(isprime(2))
#
# # Test case 3: The below line returns False
# print(isprime(3))
#
# # Test case 4: The below line returns False
# print(isprime(5))


                                    # Question Number : 5
#
# def read_in_chunks(file_object, chunk_size=1024):
#     while True:
#         data = file_object.read(chunk_size)
#         if not data:
#             break
#         yield data
#
#
# def search_file(filename, string):
#     with open(filename) as f:
#         for piece in read_in_chunks(f):
#             if string in piece:
#                 print("The given string is present in the file")
#             else:
#                 print("The given string is not in the file")
#
#
# search_file("test.txt", "Hello")


                                    # Question Number : 6

# def alphabet(word):
#     alphabets = ["a", "b", "c","d","e","f","g"," h", "i","j","k","l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w" ,"x", "y", "z" ]
#     for i in alphabets:
#         if not i in word.lower():
#             return False
#     return True
#
#
# print(alphabet("hello"))
